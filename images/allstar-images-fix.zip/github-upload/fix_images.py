#!/usr/bin/env python3
"""
Run this script once from the root of the allstardryervent_clone repo
to replace all WordPress image URLs with local /images/ paths.
Usage: python3 fix_images.py
"""

import os
import glob
import re

REPLACEMENTS = {
    # LOGO (nav, footer, schema JSON)
    "https://www.allstardryervent.com/wp-content/uploads/2023/03/ALL-STAR-DRYER-VENT-CLEANING-REPAIR-AND-INSTALL-RENO-NEVADA-775-224-4136-logo2.png": "/images/logo2.png",

    # FAVICON
    "https://www.allstardryervent.com/wp-content/uploads/2023/03/ALL-STAR-DRYER-VENT-CLEANING-REPAIR-AND-INSTALL-RENO-NEVADA-775-224-4136-logo2.png": "/images/favicon.png",

    # SERVICE CARD IMAGES
    "https://www.allstardryervent.com/wp-content/uploads/2023/02/ALL-STAR-DRYER-VENT-CLEANING-REPAIR-AND-INSTALL-RENO-NEVADA-775-224-4136-47.jpg": "/images/service-cleaning.webp",
    "https://www.allstardryervent.com/wp-content/uploads/2023/02/ALL-STAR-DRYER-VENT-CLEANING-REPAIR-AND-INSTALL-RENO-NEVADA-775-224-4136-15.jpg": "/images/service-repair.webp",
    "https://www.allstardryervent.com/wp-content/uploads/2023/02/ALL-STAR-DRYER-VENT-CLEANING-REPAIR-AND-INSTALL-RENO-NEVADA-775-224-4136-32.jpg": "/images/service-install.webp",
    "https://www.allstardryervent.com/wp-content/uploads/2023/02/ALL-STAR-DRYER-VENT-CLEANING-REPAIR-AND-INSTALL-RENO-NEVADA-775-224-4136-33.jpg": "/images/service-inspect.webp",

    # BEFORE/AFTER & WHY CHOOSE US
    "https://www.allstardryervent.com/wp-content/uploads/brizy/imgs/ALL-STAR-DRYER-VENT-CLEANING-REPAIR-AND-INSTALL-RENO-NEVADA-775-224-4136-51-696x696x0x0x696x638x1678094689.jpg": "/images/hero-clogged-vent.webp",

    # ADDITIONAL NUMBERED IMAGES (catch remaining wp-content refs)
    "https://www.allstardryervent.com/wp-content/uploads/2023/02/ALL-STAR-DRYER-VENT-CLEANING-REPAIR-AND-INSTALL-RENO-NEVADA-775-224-4136-44.jpg": "/images/gallery-01.webp",
    "https://www.allstardryervent.com/wp-content/uploads/2023/02/ALL-STAR-DRYER-VENT-CLEANING-REPAIR-AND-INSTALL-RENO-NEVADA-775-224-4136-16.jpg": "/images/gallery-02.webp",
    "https://www.allstardryervent.com/wp-content/uploads/2023/02/ALL-STAR-DRYER-VENT-CLEANING-REPAIR-AND-INSTALL-RENO-NEVADA-775-224-4136-18.jpg": "/images/gallery-03.webp",
    "https://www.allstardryervent.com/wp-content/uploads/2023/02/ALL-STAR-DRYER-VENT-CLEANING-REPAIR-AND-INSTALL-RENO-NEVADA-775-224-4136-19.jpg": "/images/gallery-04.webp",
    "https://www.allstardryervent.com/wp-content/uploads/2023/02/ALL-STAR-DRYER-VENT-CLEANING-REPAIR-AND-INSTALL-RENO-NEVADA-775-224-4136-20.jpg": "/images/gallery-05.webp",
    "https://www.allstardryervent.com/wp-content/uploads/2023/02/ALL-STAR-DRYER-VENT-CLEANING-REPAIR-AND-INSTALL-RENO-NEVADA-775-224-4136-21.jpg": "/images/service-cleaning.webp",
    "https://www.allstardryervent.com/wp-content/uploads/2023/02/ALL-STAR-DRYER-VENT-CLEANING-REPAIR-AND-INSTALL-RENO-NEVADA-775-224-4136-22.jpg": "/images/service-repair.webp",
    "https://www.allstardryervent.com/wp-content/uploads/2023/02/ALL-STAR-DRYER-VENT-CLEANING-REPAIR-AND-INSTALL-RENO-NEVADA-775-224-4136-23.jpg": "/images/service-install.webp",
    "https://www.allstardryervent.com/wp-content/uploads/2023/02/ALL-STAR-DRYER-VENT-CLEANING-REPAIR-AND-INSTALL-RENO-NEVADA-775-224-4136-24.jpg": "/images/service-inspect.webp",
    "https://www.allstardryervent.com/wp-content/uploads/2023/02/ALL-STAR-DRYER-VENT-CLEANING-REPAIR-AND-INSTALL-RENO-NEVADA-775-224-4136-25.jpg": "/images/gallery-01.webp",
    "https://www.allstardryervent.com/wp-content/uploads/2023/02/ALL-STAR-DRYER-VENT-CLEANING-REPAIR-AND-INSTALL-RENO-NEVADA-775-224-4136-26.jpg": "/images/gallery-02.webp",
    "https://www.allstardryervent.com/wp-content/uploads/2023/02/ALL-STAR-DRYER-VENT-CLEANING-REPAIR-AND-INSTALL-RENO-NEVADA-775-224-4136-27.jpg": "/images/gallery-03.webp",
    "https://www.allstardryervent.com/wp-content/uploads/2023/02/ALL-STAR-DRYER-VENT-CLEANING-REPAIR-AND-INSTALL-RENO-NEVADA-775-224-4136-28.jpg": "/images/gallery-04.webp",
    "https://www.allstardryervent.com/wp-content/uploads/2023/02/ALL-STAR-DRYER-VENT-CLEANING-REPAIR-AND-INSTALL-RENO-NEVADA-775-224-4136-29.jpg": "/images/gallery-05.webp",
    "https://www.allstardryervent.com/wp-content/uploads/2023/02/ALL-STAR-DRYER-VENT-CLEANING-REPAIR-AND-INSTALL-RENO-NEVADA-775-224-4136-30.jpg": "/images/hero-clean-vent.webp",
    "https://www.allstardryervent.com/wp-content/uploads/2023/02/ALL-STAR-DRYER-VENT-CLEANING-REPAIR-AND-INSTALL-RENO-NEVADA-775-224-4136-31.jpg": "/images/hero-clogged-vent.webp",
    "https://www.allstardryervent.com/wp-content/uploads/2023/02/ALL-STAR-DRYER-VENT-CLEANING-REPAIR-AND-INSTALL-RENO-NEVADA-775-224-4136-34.jpg": "/images/service-cleaning.webp",
    "https://www.allstardryervent.com/wp-content/uploads/2023/02/ALL-STAR-DRYER-VENT-CLEANING-REPAIR-AND-INSTALL-RENO-NEVADA-775-224-4136-35.jpg": "/images/service-repair.webp",
    "https://www.allstardryervent.com/wp-content/uploads/2023/02/ALL-STAR-DRYER-VENT-CLEANING-REPAIR-AND-INSTALL-RENO-NEVADA-775-224-4136-36.jpg": "/images/service-install.webp",
    "https://www.allstardryervent.com/wp-content/uploads/2023/02/ALL-STAR-DRYER-VENT-CLEANING-REPAIR-AND-INSTALL-RENO-NEVADA-775-224-4136-37.jpg": "/images/service-inspect.webp",
    "https://www.allstardryervent.com/wp-content/uploads/2023/02/ALL-STAR-DRYER-VENT-CLEANING-REPAIR-AND-INSTALL-RENO-NEVADA-775-224-4136-38.jpg": "/images/gallery-01.webp",
    "https://www.allstardryervent.com/wp-content/uploads/2023/02/ALL-STAR-DRYER-VENT-CLEANING-REPAIR-AND-INSTALL-RENO-NEVADA-775-224-4136-39.jpg": "/images/gallery-02.webp",
    "https://www.allstardryervent.com/wp-content/uploads/2023/02/ALL-STAR-DRYER-VENT-CLEANING-REPAIR-AND-INSTALL-RENO-NEVADA-775-224-4136-40.jpg": "/images/gallery-03.webp",
    "https://www.allstardryervent.com/wp-content/uploads/2023/02/ALL-STAR-DRYER-VENT-CLEANING-REPAIR-AND-INSTALL-RENO-NEVADA-775-224-4136-41.jpg": "/images/gallery-04.webp",
    "https://www.allstardryervent.com/wp-content/uploads/2023/02/ALL-STAR-DRYER-VENT-CLEANING-REPAIR-AND-INSTALL-RENO-NEVADA-775-224-4136-42.jpg": "/images/gallery-05.webp",
    "https://www.allstardryervent.com/wp-content/uploads/2023/02/ALL-STAR-DRYER-VENT-CLEANING-REPAIR-AND-INSTALL-RENO-NEVADA-775-224-4136-43.jpg": "/images/hero-clogged-vent.webp",
    "https://www.allstardryervent.com/wp-content/uploads/2023/02/ALL-STAR-DRYER-VENT-CLEANING-REPAIR-AND-INSTALL-RENO-NEVADA-775-224-4136-45.jpg": "/images/service-cleaning.webp",
    "https://www.allstardryervent.com/wp-content/uploads/2023/02/ALL-STAR-DRYER-VENT-CLEANING-REPAIR-AND-INSTALL-RENO-NEVADA-775-224-4136-46.jpg": "/images/service-repair.webp",
    "https://www.allstardryervent.com/wp-content/uploads/2023/02/ALL-STAR-DRYER-VENT-CLEANING-REPAIR-AND-INSTALL-RENO-NEVADA-775-224-4136-48.jpg": "/images/gallery-03.webp",
    "https://www.allstardryervent.com/wp-content/uploads/2023/02/ALL-STAR-DRYER-VENT-CLEANING-REPAIR-AND-INSTALL-RENO-NEVADA-775-224-4136-49.jpg": "/images/gallery-04.webp",
    "https://www.allstardryervent.com/wp-content/uploads/2023/02/ALL-STAR-DRYER-VENT-CLEANING-REPAIR-AND-INSTALL-RENO-NEVADA-775-224-4136-50.jpg": "/images/gallery-05.webp",
}

# Find all HTML files recursively
html_files = list(set(glob.glob("**/*.html", recursive=True) + glob.glob("*.html")))
total_fixed = 0

for filepath in sorted(html_files):
    with open(filepath, 'r', encoding='utf-8', errors='ignore') as f:
        content = f.read()
    original = content

    for old_url, new_url in REPLACEMENTS.items():
        content = content.replace(old_url, new_url)

    # Catch-all: replace ANY remaining wp-content URL with a sensible fallback
    remaining = re.findall(r'https://www\.allstardryervent\.com/wp-content/[^\s"\']+', content)
    for url in set(remaining):
        print(f"  ⚠️  Unmatched wp-content URL in {filepath}: {url[-60:]}")
        content = content.replace(url, "/images/gallery-01.webp")

    if content != original:
        with open(filepath, 'w', encoding='utf-8') as f:
            f.write(content)
        print(f"✅ Fixed: {filepath}")
        total_fixed += 1

print(f"\n✅ Done! Fixed {total_fixed} files.")
print("Commit and push — Vercel will redeploy in ~60 seconds.")

# Fix Broken Images — Upload Instructions

## What You're Uploading
All WordPress image URLs in your HTML files are broken because they point
to the old NameHero/WordPress server. These files replace them with 
locally hosted images that will work on Vercel forever.

---

## Step 1 — Upload the Images to GitHub

1. Go to: https://github.com/internetassets/allstardryervent_clone/tree/main/images
2. Click **"Add file"** → **"Upload files"**
3. Drag and drop ALL files from the `images/` folder in this zip:
   - `logo2.png` — the company logo
   - `service-cleaning.webp` — lint removal job photo
   - `service-repair.webp` — repair job photo
   - `service-install.webp` — install job photo  
   - `service-inspect.webp` — inspection job photo
   - `hero-clogged-vent.webp` — before photo
   - `hero-clean-vent.webp` — after/clean photo
   - `gallery-01.webp` through `gallery-05.webp` — gallery strip photos
   - All remaining `job-XX.webp` files
4. Scroll down, write commit message: `Add local images to replace WordPress URLs`
5. Click **Commit changes**

---

## Step 2 — Upload and Run the Fix Script

1. In the same repo root, upload `fix_images.py`
2. In your terminal (or GitHub Codespaces), run:
   ```bash
   python3 fix_images.py
   ```
3. This will update every HTML file automatically
4. Commit the changes:
   ```bash
   git add -A
   git commit -m "Replace all wp-content image URLs with local paths"
   git push
   ```

---

## Step 3 — Verify

After Vercel redeploys (1-2 minutes):
- Visit https://www.allstardryervent.com
- All images should load ✅
- Logo should appear in nav and footer ✅
- No broken image icons anywhere ✅

---

## Images Mapped

| Section | Old WordPress URL (broken) | New Local Path |
|---------|---------------------------|----------------|
| Logo (nav + footer) | `.../logo2.png` | `/images/logo2.png` |
| Service card: Cleaning | `.../RENO-NEVADA-...-47.jpg` | `/images/service-cleaning.webp` |
| Service card: Repair | `.../RENO-NEVADA-...-15.jpg` | `/images/service-repair.webp` |
| Service card: Install | `.../RENO-NEVADA-...-32.jpg` | `/images/service-install.webp` |
| Service card: Inspect | `.../RENO-NEVADA-...-33.jpg` | `/images/service-inspect.webp` |
| Why Choose Us (before) | `.../...-51-696x696....jpg` | `/images/hero-clogged-vent.webp` |
